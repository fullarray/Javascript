<template>
    <div class="rowmain ">
	   <div class="col-md-4 col-md-offset-4 entry text-center">
		<h1>{{ msg }}</h1>
		<h3>Links</h3>
		<ul>
		   <li><router-link to="/" data-toggle="modal" data-target="#addNewPost">New Post</router-link></li>
		      <li><router-link to="/blog">See posts</router-link></li>
		</ul>
		<br/>
	   </div>	
	</div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
      msg: 'BLOG'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

*{
   font-family: Segoe UI,Frutiger,Frutiger Linotype,Dejavu Sans,Helvetica Neue,Arial,sans-serif ;
}


.entry{
   border: solid #f3f3f3 1px;
   color: #333;
}

h1, h2 {
  font-weight: normal;color: #555;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
